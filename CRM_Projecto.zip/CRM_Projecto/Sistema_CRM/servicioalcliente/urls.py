from django.urls import path
from . import views

app_name = 'servicioalcliente'

urlpatterns = [
    path('chat_canal/', views.chat_canal, name='chat_canal'),
    path('limpiar_chat/', views.limpiar_chat, name='limpiar_chat'),
]
