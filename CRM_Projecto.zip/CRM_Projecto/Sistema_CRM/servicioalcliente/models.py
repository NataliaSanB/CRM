from django.db import models
from django.contrib.auth.models import User

class ChatMensaje(models.Model):
    usuario = models.ForeignKey(User, on_delete=models.CASCADE)
    mensaje = models.TextField()
    es_bienvenida = models.BooleanField(default=False)