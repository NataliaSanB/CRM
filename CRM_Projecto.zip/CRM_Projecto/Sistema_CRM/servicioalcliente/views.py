from django.shortcuts import render
from django.http import JsonResponse
from .models import ChatMensaje
from .forms import MensajeForm
from django.views.decorators.csrf import csrf_exempt

@csrf_exempt
def chat_canal(request):
    form = MensajeForm()
    bienvenida = "Hola, ¿en qué puedo ayudarte hoy? Estoy aquí para responder a tus preguntas sobre nuestro CRM. ¿Te gustaría saber más o programar una demostración?"

    if request.method == 'POST':
        form = MensajeForm(request.POST)
        if form.is_valid():
            nuevo_mensaje = form.cleaned_data['nuevo_mensaje']
            ChatMensaje.objects.create(usuario=request.user, mensaje=nuevo_mensaje)
            mensajes = ChatMensaje.objects.filter(usuario=request.user)
            print(mensajes)

        elif 'limpiar_chat' in request.POST:
            limpiar_chat(request)
            print('Chat limpiado exitosamente')
            return JsonResponse({'mensaje': 'Chat limpiado exitosamente'})

    mensajes = ChatMensaje.objects.filter(usuario=request.user)
    print(mensajes)
    return render(request, 'servicioalcliente/chat_canal.html', {'mensajes': mensajes, 'form': form, 'bienvenida': bienvenida})

# En tu vista (views.py)
def limpiar_chat(request):
    if request.method == 'POST':
        # Excluir mensajes de bienvenida al limpiar el chat
        mensajes_bienvenida = ChatMensaje.objects.filter(usuario=request.user, es_bienvenida=True)
        mensajes_bienvenida.delete()

        # Limpiar otros mensajes
        mensajes_no_bienvenida = ChatMensaje.objects.filter(usuario=request.user, es_bienvenida=False)
        mensajes_no_bienvenida.delete()

        return JsonResponse({'mensaje': 'Chat limpiado exitosamente'})
    else:
        # Manejar un error si la solicitud no es de tipo POST
        return JsonResponse({'error': 'La solicitud debe ser de tipo POST'})
