# forms.py en la aplicación servicioalcliente
from django import forms

class MensajeForm(forms.Form):
    nuevo_mensaje = forms.CharField(max_length=500)

