import csv
from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect, get_object_or_404
from django.http import HttpResponse
from django.urls import reverse
from django.views import View

from .forms import AddClienteForm, AddComentarioForm, AddFileForm
from .models import Cliente, Comentario, ClienteFile

from team.models import Team


@login_required
def clientes_export(request):
    clientes = Cliente.objects.filter(creado_por=request.user)

    response = HttpResponse(
        content_type="text/csv",
        headers={"Content-Disposition": 'attachment; filename="clientes.csv"'},
    )

    writer = csv.writer(response)
    writer.writerow(['Cliente', 'Descripción', 'Create at', 'Creado por'])


    for cliente in clientes:
        writer.writerow([cliente.nombre, cliente.descripción, cliente.created_at, cliente.creado_por])

    return response

def convertir_cliente(request, pk):
    # Lógica para convertir un cliente
    return redirect(reverse('clientes:detalle', args=[pk]))


@login_required
def clientes_lista(request):
    clientes = Cliente.objects.filter(creado_por=request.user)
    return render(request, 'cliente/clientes_lista.html', {'clientes': clientes})


@login_required
def clientes_detalle(request, pk):
    cliente = get_object_or_404(Cliente, creado_por=request.user, pk=pk)

    if request.method == 'POST':
        form = AddComentarioForm(request.POST)
        if form.is_valid():
            comentario = form.save(commit=False)
            comentario.creado_por = request.user
            comentario.cliente = cliente

            # Asegúrate de establecer un valor para el campo 'team'
            comentario.team = cliente.team  # o ajusta según la relación que tengas

            comentario.save()
            return redirect('clientes:detalle', pk=pk)

    else:
        form = AddComentarioForm()

    return render(request, 'cliente/clientes_detalle.html', {
        'cliente': cliente,
        'add_comentario_form': form,
    })


@login_required
def agregar_clientes(request):
    team = Team.objects.filter(creado_por=request.user).first()

    if not team:
        messages.error(request, "No hay equipos disponibles. Crea un equipo antes de agregar un cliente.")
        return redirect('clientes:lista')

    if request.method == 'POST':
        form = AddClienteForm(request.POST)

        if form.is_valid():
            cliente = form.save(commit=False)
            cliente.creado_por = request.user
            cliente.team = team
            cliente.save()

            messages.success(request, "El cliente fue creado.")
            return redirect('clientes:lista')

    else:
        form = AddClienteForm()

    return render(request, 'cliente/agregar_clientes.html', {
        'form': form,
        'team': team
    })

@login_required
def editar_clientes(request, pk):
    cliente = get_object_or_404(Cliente, creado_por=request.user, pk=pk)

    if request.method == 'POST':
        form = AddClienteForm(request.POST, instance=cliente)

        if form.is_valid():
            form.save()

            messages.success(request, "Cambios guardados.")

            return redirect('clientes:lista')
    else:
        form = AddClienteForm(instance=cliente)

    return render(request, 'cliente/editar_clientes.html', {
        'form': form
    })


@login_required
def borrar_clientes(request, pk):
    cliente = get_object_or_404(Cliente, creado_por=request.user, pk=pk)
    cliente.delete()

    messages.success(request, "El cliente fue eliminado.")

    return redirect('clientes:lista')


@login_required
def add_file_cliente(request, pk):
    cliente = get_object_or_404(Cliente, creado_por=request.user, pk=pk)

    if request.method == 'POST':
        file_form = AddFileForm(request.POST, request.FILES)
        if file_form.is_valid():
            archivo = file_form.save(commit=False)
            archivo.cliente = cliente
            archivo.team = cliente.team
            archivo.creado_por = request.user
            archivo.save()

            messages.success(request, "Archivo enviado correctamente.")
            return redirect('clientes:detalle', pk=pk)

    else:
        file_form = AddFileForm()

    return render(request, 'cliente/add_file_cliente.html', {
        'cliente': cliente,
        'file_form': file_form
    })


class AddFileClienteView(View):
    template_name = 'cliente/clientes_detalle.html'

    def post(self, request, pk):
        cliente = get_object_or_404(Cliente, pk=pk)
        file_form = AddFileForm(request.POST, request.FILES)

        if file_form.is_valid():
            archivo = file_form.save(commit=False)
            archivo.cliente = cliente
            archivo.team = cliente.team
            archivo.creado_por = request.user
            archivo.save()

            messages.success(request, "Archivo enviado correctamente.")
            return redirect('clientes:detalle', pk=pk)

        return render(request, self.template_name, {'cliente': cliente, 'file_form': file_form})



