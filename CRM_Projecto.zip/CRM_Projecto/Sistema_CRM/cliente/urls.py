from django.urls import path

from . import views
from .views import AddFileClienteView

app_name = 'clientes'

urlpatterns = [
    path('', views.clientes_lista, name='lista'),
    path('<int:pk>/', views.clientes_detalle, name='detalle' ),
    path('<int:pk>/borrar/', views.borrar_clientes, name='borrar' ),
    path('<int:pk>/editar/', views.editar_clientes, name='editar' ),
    path('<int:pk>/convertir/', views.convertir_cliente, name='convertir_cliente'),
    path('<int:pk>/add-comentario/', views.clientes_detalle, name='add_comentario' ),
    path('<int:pk>/add_file/', AddFileClienteView.as_view(), name='add_file'),
    path('agregar/', views.agregar_clientes, name='agregar'),
    path('exportar/', views.clientes_export, name='exportar'),
]
