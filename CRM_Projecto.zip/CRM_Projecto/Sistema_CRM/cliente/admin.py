from django.contrib import admin

from .models import Cliente, Comentario

admin.site.register(Cliente)
admin.site.register(Comentario)
