from django.contrib.auth.models import User
from django.db import models

from team.models import Team

class Cliente(models.Model):
   team = models.ForeignKey(Team, related_name='clientes', on_delete=models.CASCADE)
   nombre = models.CharField(max_length=255)
   email = models.EmailField()
   descripción = models.TextField(blank=True, null=True)
   creado_por = models.ForeignKey(User, related_name='clientes', on_delete=models.CASCADE)
   created_at = models.DateTimeField(auto_now_add=True)
   modified_at = models.DateTimeField(auto_now=True)
   mensajes = models.TextField(blank=True, null=True)

   class Meta:
      ordering = ('nombre',)

   def __str__(self):
      return self.nombre

class Comentario(models.Model):
   team = models.ForeignKey(Team, related_name='cliente_comentarios', on_delete=models.CASCADE)
   cliente = models.ForeignKey(Cliente, related_name='comentarios', on_delete=models.CASCADE)
   contenido = models.TextField(blank=True, null=True)
   creado_por = models.ForeignKey(User, related_name='cliente_comentarios', on_delete=models.CASCADE)
   created_at = models.DateTimeField(auto_now_add=True)
   
   def __str__(self):
      return self.creado_por.username
   
class ClienteFile(models.Model):
    team = models.ForeignKey(Team, related_name='cliente_files', on_delete=models.CASCADE)
    cliente = models.ForeignKey(Cliente, related_name='files', on_delete=models.CASCADE)
    file = models.FileField(upload_to='clientefiles')
    creado_por = models.ForeignKey(User, related_name='cliente_files', on_delete=models.CASCADE, null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.creado_por.username
    


