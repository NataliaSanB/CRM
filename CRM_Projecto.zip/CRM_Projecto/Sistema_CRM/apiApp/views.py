from django.shortcuts import render
from django.http import JsonResponse
from apiApp.models import Prospecto, Cliente

from .serializers import ClienteSerializer, ProspectoSerializer
from rest_framework.response import Response
from rest_framework import status
from rest_framework.decorators import api_view


#Utiliza una varible de python (emp) y nos devuelve un Json utlizando JsonResponse
@api_view(['GET','POST'])
def prospecto_list(request):
    if request.method == 'GET':
        prospectos = Cliente.objects.all()
        serializer = ClienteSerializer(prospectos, many = True)
        return Response(serializer.data)

    if request.method == 'POST':
        serializer = ClienteSerializer(data = request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
    return Response(serializer.errors, status= status.HTTP_400_BAD_REQUEST )

@api_view(['GET', 'PUT', 'DELETE'])
def prospecto_detail(request, pk):
    try:
        prospecto = Prospecto.objects.get(pk=pk)
    except prospecto.DoesNotExist:
        return Response(status=status.HTTP_404_NOT_FOUND)
    
    if request.method == 'GET':
        serializer = ProspectoSerializer(prospecto)
        return Response(serializer.data)
    
    if request.method == 'PUT':
        serializer = ProspectoSerializer(prospecto, data = request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


    if request.method == 'DELETE':
        prospecto.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)

@api_view(['GET','POST'])
def cliente_list(request):
    if request.method == 'GET':
        clientes = Cliente.objects.all()
        serializer = ClienteSerializer(clientes, many = True)
        return Response(serializer.data)

    if request.method == 'POST':
        serializer = ClienteSerializer(data = request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
    return Response(serializer.errors, status= status.HTTP_400_BAD_REQUEST )

@api_view(['GET', 'PUT', 'DELETE'])
def cliente_detail(request, pk):
    try:
        cliente = Cliente.objects.get(pk=pk)
    except Cliente.DoesNotExist:
        return Response(status=status.HTTP_404_NOT_FOUND)
    
    if request.method == 'GET':
        serializer = ClienteSerializer(cliente)
        return Response(serializer.data)
    
    if request.method == 'PUT':
        serializer = ClienteSerializer(cliente, data = request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


    if request.method == 'DELETE':
        cliente.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)
    

 

