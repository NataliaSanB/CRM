from django.db import models

# Create your models here.

class Prospecto(models.Model):
   NUEVO = 'nuevo'
   CONTACTADO = 'contactado'
   GANADO = 'ganado'
   PERDIDO = 'perdido'

   OPCIONES_ESTADO = (
        (NUEVO, 'Nuevo'),
        (CONTACTADO, 'Contactado'),
        (GANADO, 'Ganado'),
        (PERDIDO, 'Perdido'),
   )

   BAJA = 'baja'
   MEDIA = 'media'
   ALTA = 'alta'

   OPCIONES_PRIORIDAD = (
        (BAJA, 'Baja'),
        (MEDIA, 'Media'),
        (ALTA, 'Alta'),
    )

   id = models.IntegerField(primary_key=True)
   nombre = models.CharField(max_length=255)
   email = models.EmailField()
   descripción = models.TextField(blank=True, null=True)
   prioridad = models.CharField(max_length=10, choices=OPCIONES_PRIORIDAD, default=MEDIA)
   estado = models.CharField(max_length=10, choices=OPCIONES_ESTADO, default=NUEVO)
   

   def __str__(self):
      return str(self.id) + " " + self.nombre + "" + (self.email) + " " + (self.descripción) + " " + (self.prioridad) + " " + (self.estado)


class Cliente(models.Model):
    id = models.IntegerField(primary_key=True)
    nombre = models.CharField(max_length=255)
    email = models.EmailField()
    descripción = models.TextField(blank=True, null=True)

    def __str__(self):
       return str(self.id) + " " + self.nombre + " " + (self.email) + " " + (self.descripción)
