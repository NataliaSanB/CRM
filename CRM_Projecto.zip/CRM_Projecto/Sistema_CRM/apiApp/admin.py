from django.contrib import admin
from apiApp.models import Cliente, Prospecto


# Register your models here.
class ProspectoAdmin(admin.ModelAdmin):
    list_display = ['nombre', 'email' , 'descripción', 'prioridad', 'estado']

admin.site.register(Prospecto, ProspectoAdmin)

class ClienteAdmin(admin.ModelAdmin):
    list_display = ['nombre', 'email', 'descripción']

admin.site.register(Cliente, ClienteAdmin)
