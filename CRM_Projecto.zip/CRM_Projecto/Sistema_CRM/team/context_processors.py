from .models import Team

def active_team(request):
    active_team = None

    if request.user.is_authenticated:
        user_profile = getattr(request.user, 'userprofile', None)
        if user_profile:
            active_team = user_profile.get_active_team()

    return {'active_team': active_team}
