from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.shortcuts import render, get_object_or_404, redirect

from .forms import TeamForm
from team.models import Team

@login_required
def team_lista(request):
    teams = Team.objects.filter(members__in=[request.user])

    return render(request, 'team/team_lista.html', {'teams': teams})

@login_required
def teams_activate(request, pk):
    team = Team.objects.filter(members__in=[request.user]).get(pk=pk)
    userprofile = request.user.userprofile
    userprofile.teams_activate = team
    userprofile.save()

    return redirect('team:detalle', pk=pk)

@login_required
def detalle(request,pk):
    team = get_object_or_404(Team, creado_por=request.user, pk=pk)

    return render(request, 'team/detalle.html', {'team': team })

@login_required
def editar_team(request, pk):
    team = get_object_or_404(Team, creado_por=request.user, pk=pk)
    form = TeamForm(instance=team)
    
    if request.method =='POST':
        # Verifica que el equipo pertenece al usuario actual antes de permitir la edición
        if team.creado_por == request.user:
            form = TeamForm(request.POST, instance=team)

            if form.is_valid():
                form.save()
                messages.success(request, 'Los cambios fueron guardados')
                return redirect('perfil_usuario:micuenta')
        else:
            # Agrega un mensaje de error si el usuario no tiene permisos para editar este equipo
            messages.error(request, 'No tienes permisos para editar este equipo.')

    return render(request, 'team/editar_team.html', {'team': team, 'form': form})
