from django.urls import path

from . import views

app_name = 'team'

urlpatterns = [
    path('', views.team_lista, name='lista'),
    path('detalle/<int:pk>/', views.detalle, name='detalle'),
    path('<int:pk>/edit/', views.editar_team, name='editar'),
    path('<int:pk>/activate/', views.teams_activate, name='activado'),
]