from django.contrib.auth.models import User
from django.db import models


class Plan(models.Model):
     nombre = models.CharField(max_length=50)
     precio = models.IntegerField()
     descripcion = models.TextField(blank=True, null=True)
     max_prospectos = models.IntegerField()
     max_clientes = models.IntegerField()
    
     def __str__(self):
        return self.nombre
    
class Team(models.Model):
    plan = models.ForeignKey(Plan, related_name='teams',blank=True, null=True, on_delete=models.CASCADE)
    nombre = models.CharField(max_length=100)
    miembros = models.ManyToManyField(User, related_name='teams')
    creado_por = models.ForeignKey(User, related_name='team_creado', on_delete=models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.nombre
    
    def get_plan(self):
        if self.plan:
            return self.plan
        else:
            if Plan.objects.count() > 0:
                self.plan = Plan.objects.all().first()
                self.save()
            else:
                plan = Plan.objects.create(nombre='Free', precio=0, max_prospectos=3, max_clientes=3)
                self.plan = plan
                self.save()

            return self.plan
            
    