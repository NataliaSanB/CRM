document.addEventListener('DOMContentLoaded', function() {
    document.getElementById('limpiarChatBtn').addEventListener('click', function() {
      // Lógica para limpiar solo los mensajes enviados por el usuario mediante una solicitud AJAX
      fetch('/servicioalcliente/limpiar_chat/', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-CSRFToken': getCookie('csrftoken'),
        },
        body: JSON.stringify({ limpiar_chat: true }),
      })
      .then(response => response.json())
      .then(data => {
        console.log(data);
        if (data.mensaje === 'Chat limpiado exitosamente') {
          cargarContenidoChat();
        }
      })
      .catch(error => {
        console.error('Error al limpiar el chat:', error);
      });
    });
  
    function cargarContenidoChat() {
      var chatContainer = document.querySelector('.chat-box');
      if (chatContainer) {
        chatContainer.innerHTML = '';
      } else {
        console.error('Error al limpiar el chat: El elemento chat-box no fue encontrado.');
      }
    }
  
    function getCookie(name) {
      var cookieValue = null;
      if (document.cookie && document.cookie !== '') {
        var cookies = document.cookie.split(';');
        for (var i = 0; i < cookies.length; i++) {
          var cookie = cookies[i].trim();
          if (cookie.substring(0, name.length + 1) === (name + '=')) {
            cookieValue = decodeURIComponent(cookie.substring(name.length + 1));
            break;
          }
        }
      }
      return cookieValue;
    }
  });
  
  // main.js
document.addEventListener('DOMContentLoaded', function () {
  // Datos para los gráficos
  var clientesData = {
      labels: ['Clientes'],
      datasets: [{
          label: 'Clientes',
          data: [1000],
          backgroundColor: ['#82d616'],
          borderColor: ['#2ecc71'],
          borderWidth: 2
      }]
  };

  var prospectosData = {
      labels: ['Prospectos'],
      datasets: [{
          label: 'Prospectos',
          data: [500],
          backgroundColor: ['#17c1e8'],
          borderColor: ['#0dcaf0'],
          borderWidth: 2
      }]
  };

  var equiposData = {
      labels: ['Equipos'],
      datasets: [{
          label: 'Equipos',
          data: [10],
          backgroundColor: ['#8392ab'],
          borderColor: ['#596cff'],
          borderWidth: 2
      }]
  };

  // Configuración de los gráficos
  var chartOptions = {
      scales: {
          y: {
              beginAtZero: true
          }
      }
  };

  // Renderizar gráficos
  var clientesChart = new Chart(document.getElementById('clientes-chart'), {
      type: 'bar',
      data: clientesData,
      options: chartOptions
  });

  var prospectosChart = new Chart(document.getElementById('prospectos-chart'), {
      type: 'bar',
      data: prospectosData,
      options: chartOptions
  });

  var equiposChart = new Chart(document.getElementById('equipos-chart'), {
      type: 'bar',
      data: equiposData,
      options: chartOptions
  });
});


