from django.contrib.auth.models import User
from django.db import models

from team.models import Team

class Prospecto(models.Model):
   NUEVO = 'nuevo'
   CONTACTADO = 'contactado'
   GANADO = 'ganado'
   PERDIDO = 'perdido'

   OPCIONES_ESTADO = (
        (NUEVO, 'Nuevo'),
        (CONTACTADO, 'Contactado'),
        (GANADO, 'Ganado'),
        (PERDIDO, 'Perdido'),
   )

   BAJA = 'baja'
   MEDIA = 'media'
   ALTA = 'alta'

   OPCIONES_PRIORIDAD = (
        (BAJA, 'Baja'),
        (MEDIA, 'Media'),
        (ALTA, 'Alta'),
    )

   team = models.ForeignKey(Team, related_name='prospectos', on_delete=models.CASCADE)
   nombre = models.CharField(max_length=255)
   email = models.EmailField()
   descripción = models.TextField(blank=True, null=True)
   prioridad = models.CharField(max_length=10, choices=OPCIONES_PRIORIDAD, default=MEDIA)
   estado = models.CharField(max_length=10, choices=OPCIONES_ESTADO, default=NUEVO)
   converted_to_cliente = models.BooleanField(default=False)
   creado_por = models.ForeignKey(User, related_name='prospectos', on_delete=models.CASCADE)
   created_at = models.DateTimeField(auto_now_add=True)
   modified_at = models.DateTimeField(auto_now=True)

   class Meta:
      ordering = ('nombre',)

   def __str__(self):
      return self.nombre
   
class ProspectoFile(models.Model):
    team = models.ForeignKey(Team, related_name='prospecto_files', on_delete=models.CASCADE)
    prospecto = models.ForeignKey(Prospecto, related_name='files', on_delete=models.CASCADE)
    file = models.FileField(upload_to='prospectofiles')
    creado_por = models.ForeignKey(User, related_name='prospecto_files', on_delete=models.CASCADE, null=True, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.creado_por.username
   
class Comentario(models.Model):
   team = models.ForeignKey(Team, related_name='prospecto_comentarios', on_delete=models.CASCADE)
   prospecto = models.ForeignKey(Prospecto, related_name='comentarios', on_delete=models.CASCADE)
   contenido = models.TextField(blank=True, null=True)
   creado_por = models.ForeignKey(User, related_name='prospecto_comentarios', on_delete=models.CASCADE)
   created_at = models.DateTimeField(auto_now_add=True)
   
   def __str__(self):
      return self.creado_por.username
   


   
