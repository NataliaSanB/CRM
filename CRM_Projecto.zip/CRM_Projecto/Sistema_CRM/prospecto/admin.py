from django.contrib import admin

from .models import Prospecto, Comentario, ProspectoFile

admin.site.register(Prospecto)
admin.site.register(Comentario)
admin.site.register(ProspectoFile)
