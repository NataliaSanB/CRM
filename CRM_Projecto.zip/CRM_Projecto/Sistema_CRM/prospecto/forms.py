from django import forms 

from .models import Prospecto, Comentario, ProspectoFile

class AddProspectoForm(forms.ModelForm):
    email = forms.EmailField()

    class Meta:
        model = Prospecto
        fields = ('nombre', 'email', 'descripción', 'prioridad', 'estado')
        widgets = {
            'descripción': forms.Textarea(attrs={'rows': 4}),
        }
    def clean_nombre(self):
            nombre = self.cleaned_data['nombre']
            if not nombre or not nombre[0].isupper() or not nombre[1:].islower():
                raise forms.ValidationError("El nombre debe empezar con mayúscula y puede contener solo minúsculas después de la primera letra.")
            if len(nombre) < 3:
                raise forms.ValidationError("El nombre debe tener al menos 3 caracteres.")
            elif len(nombre) > 50:
                raise forms.ValidationError("El nombre no puede tener más de 50 caracteres.")
            if not nombre.isalpha():
                raise forms.ValidationError("El nombre solo puede contener letras.")
            if not nombre:
                raise forms.ValidationError("El nombre no puede estar vacío.")
            return nombre

    def clean_email(self):
            email = self.cleaned_data['email']
            if '@' not in email or '.' not in email:
                raise forms.ValidationError("El email debe contener al menos un '@' y un '.'.")
            return email    


class AddComentarioForm(forms.ModelForm):
    class Meta:
        model = Comentario
        fields = ('contenido',)

class AddFileForm(forms.ModelForm):
    class Meta:
        model = ProspectoFile
        fields = ('file', )



