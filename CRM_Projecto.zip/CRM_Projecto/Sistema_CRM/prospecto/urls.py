from django.urls import path
from .views import AddFileView
from .views import  agregar_prospecto, prospectos_lista

from . import views

app_name = 'prospectos'

urlpatterns = [

    path('agregar-prospecto/', agregar_prospecto, name='agregar_prospecto'),
    path('lista/', views.prospectos_lista, name='lista'),
    path('<int:pk>/', views.prospectos_detalle, name='detalle'),
    path('<int:pk>/delete/', views.prospectos_borrar, name='borrar'),
    path('<int:pk>/editar/', views.editar_prospecto, name='editar'),
    path('dashboard/clientes/<int:pk>/convertir/', views.convertir_cliente, name='convertir'),
    path('prospectos/<int:pk>/add_file/', AddFileView.as_view(), name='add_file'),
]
