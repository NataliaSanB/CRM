from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect, get_object_or_404
from django.views.generic import ListView
from django.views import View


from .forms import AddProspectoForm, AddComentarioForm, AddFileForm
from .models import Prospecto, ProspectoFile  # Agrega la importación de ProspectoFile
from cliente.models import Cliente, Comentario as ClienteComentario
from team.models import Team



class ProspectoListView( ListView):
    model = Prospecto

@login_required
def prospectos_lista(request):
    team = Team.objects.filter(creado_por=request.user).first()
    prospectos = Prospecto.objects.filter(creado_por=request.user, converted_to_cliente=False)

    return render(request, 'prospecto/prospectos_lista.html', {
        'prospectos': prospectos,
        'team': team,
    })

@login_required
def prospectos_detalle(request, pk):
    prospecto = get_object_or_404(Prospecto, creado_por=request.user, pk=pk)

    if request.method == 'POST':
        form, file_form = handle_post_request(request, prospecto)
        if form.is_valid() and file_form.is_valid():
            save_comment_and_file(form, file_form, prospecto)
            return redirect('prospectos:detalle', pk=pk)

    else:
        form = AddComentarioForm()
        file_form = AddFileForm()

    return render(request, 'prospecto/prospectos_detalle.html', {
        'prospecto': prospecto,
        'add_comentario_form': form,
        'file_form': file_form
    })

def handle_post_request(request, prospecto):
    comentario_form = AddComentarioForm(request.POST)
    file_form = AddFileForm(request.POST, request.FILES)
    return comentario_form, file_form

def save_comment_and_file(comentario_form, file_form, prospecto):
    comentario = comentario_form.save(commit=False)
    comentario.creado_por = prospecto.creado_por
    comentario.team = prospecto.team
    comentario.prospecto = prospecto
    comentario.save()

    archivo = file_form.save(commit=False)
    archivo.prospecto = prospecto
    archivo.creado_por = prospecto.creado_por
    archivo.team = prospecto.team
    archivo.save()

class AddFileView(View):
    template_name = 'prospecto/prospectos_detalle.html'

    def post(self, request, pk):
        prospecto = get_object_or_404(Prospecto, pk=pk)
        file_form = AddFileForm(request.POST, request.FILES)

        if file_form.is_valid():
            archivo = file_form.save(commit=False)
            archivo.prospecto = prospecto
            archivo.team = prospecto.team
            archivo.creado_por = request.user  # Asigna el creador del archivo
            archivo.save()

            messages.success(request, "Archivo enviado correctamente.")
            return redirect('prospectos:detalle', pk=pk)

        return render(request, self.template_name, {'prospecto': prospecto, 'file_form': file_form})

@login_required
def prospectos_borrar(request, pk):
    prospecto = get_object_or_404(Prospecto, creado_por=request.user, pk=pk)
    prospecto.delete()
    
    messages.success(request, "El prospecto fue eliminado.")

    return redirect('prospectos:lista')

@login_required
def editar_prospecto(request, pk):
    prospecto = get_object_or_404(Prospecto, creado_por=request.user, pk=pk)

    if request.method == 'POST':
        form = AddProspectoForm(request.POST, instance=prospecto)

        if form.is_valid():
            form.save()
            
            messages.success(request, "Cambios guardados.")

            return redirect('prospectos:lista')
    else: 
        form = AddProspectoForm(instance=prospecto)
    
    return render(request, 'prospecto/editar_prospecto.html', {
        'form': form
    })

@login_required
def agregar_prospecto(request):
    team = Team.objects.filter(creado_por=request.user).first()

    if not team:
        messages.error(request, "No hay equipos disponibles. Crea un equipo antes de agregar un prospecto.")
        return redirect('prospectos_lista')

    if request.method == 'POST':
        form = AddProspectoForm(request.POST)

        if form.is_valid():
            prospecto = form.save(commit=False)
            prospecto.creado_por = request.user
            prospecto.team = team
            prospecto.save()

            messages.success(request, "El prospecto fue creado.")
            return redirect('prospectos:lista')
        else:
            print(form.errors)
    else:
        form = AddProspectoForm()

    return render(request, 'prospecto/agregar_prospecto.html', {
        'form': form,
        'team': team,
    })

@login_required
def convertir_cliente(request, pk):
    prospecto = get_object_or_404(Prospecto, creado_por=request.user, pk=pk)
    team = Team.objects.filter(creado_por=request.user).first()

    cliente = Cliente.objects.create(
        nombre=prospecto.nombre,
        email=prospecto.email,
        descripción=prospecto.descripción,
        creado_por=request.user,
        team=team,
    )

    prospecto.converted_to_cliente = True
    prospecto.save()

    comentarios = prospecto.comentarios.all()

    for comentario in comentarios:
        ClienteComentario.objects.create(
            cliente=cliente,
            contenido=comentario.contenido,
            creado_por=comentario.creado_por,
            team=team
        )

    messages.success(request, "El prospecto se convirtió en cliente.")

    return redirect('prospectos:lista')