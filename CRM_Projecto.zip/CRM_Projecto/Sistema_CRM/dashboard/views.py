from django.contrib.auth.decorators import login_required
from django.shortcuts import render

from prospecto.models import Prospecto
from cliente.models import Cliente
from team.models import Team

@login_required
def dashboard(request):
    team = Team.objects.filter(creado_por=request.user).first()

    if team:
        prospectos = Prospecto.objects.filter(team=team, converted_to_cliente=False).order_by('-created_at')[:5]
        clientes = Cliente.objects.filter(team=team).order_by('-created_at')[:5]
    else:
        prospectos = []
        clientes = []

    return render(request, 'dashboard/dashboard.html', {
        'prospectos': prospectos,
        'clientes': clientes,
    })


def detalle(request, pk):
    # Lógica para la vista de detalle
    return render(request, 'dashboard/detalle.html', {'pk': pk})
