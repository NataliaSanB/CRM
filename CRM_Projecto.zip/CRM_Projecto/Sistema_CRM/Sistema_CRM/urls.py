from django.conf import settings
from django.conf.urls.static import static
from django.contrib import admin
from django.contrib.auth import views as auth_views
from django.urls import path, include
from apiApp import views

from core.views import index, nosotros
from perfil_usuario.forms import LoginForm

urlpatterns = [
    path('', index, name='index'),
    path('dashboard/prospectos/', include('prospecto.urls')),
    path('dashboard/clientes/', include('cliente.urls')),
    path('dashboard/teams/', include('team.urls')),
    path('dashboard/', include('perfil_usuario.urls')), 
    path('dashboard/', include('dashboard.urls')),
    path('nosotros/', nosotros, name='nosotros'),
    path('entrar/', auth_views.LoginView.as_view(template_name='perfil_usuario/inicio_sesion.html', authentication_form=LoginForm), name='inicio_sesion'),
    path('servicioalcliente/', include('servicioalcliente.urls')),
    path('salir/', auth_views.LogoutView.as_view(), name='cerrar_sesion'),
    path('admin/', admin.site.urls),
    path ("prospecto/", views.prospecto_list),
    path ("prospecto/<int:pk>", views.prospecto_detail),
    path ("cliente/", views.cliente_list),
    path ("cliente/<int:pk>", views.cliente_detail),
] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
