from django import forms
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.contrib.auth.models import User




class LoginForm(AuthenticationForm):
    username = forms.CharField(widget=forms.TextInput(attrs={
        'placeholder': 'Ingrese su nombre',
        'class': 'w-full my-4 py-4 px-6 rounded-xl bg-gray-300',
    }))
    password = forms.CharField(widget=forms.PasswordInput(attrs={
        'placeholder': 'Ingrese su contraseña',
        'class': 'w-full my-4 py-4 px-6 rounded-xl bg-gray-300',
    }))


class SignupForm(UserCreationForm):
    usuario = forms.CharField(widget=forms.TextInput(attrs={
        'placeholder': 'Ingrese su nombre',
        'class': 'w-full my-4 py-4 px-6 rounded-xl bg-gray-100'
    }))
    email = forms.CharField(widget=forms.EmailInput(attrs={
        'placeholder': 'Ingrese un correo electrónico',
        'class': 'w-full my-4 py-4 px-6 rounded-xl bg-gray-100'
    }))
    contraseña = forms.CharField(widget=forms.PasswordInput(attrs={
        'placeholder': 'Escriba una contraseña',
        'class': 'w-full my-4 py-4 px-6 rounded-xl bg-gray-100'
    }))
    repetir_contraseña = forms.CharField(widget=forms.PasswordInput(attrs={
        'placeholder': 'Repita la contraseña',
        'class': 'w-full my-4 py-4 px-6 rounded-xl bg-gray-100'
    }))

    class Meta:
        model = User
        fields = ('username', 'email', 'password1', 'password2')
