from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect
from django.contrib import messages
from django.urls import reverse

from .models import PerfilUsuario
from django.contrib.auth import login

from team.models import Team
from .forms import SignupForm

def registro(request):
    if request.method == 'POST':
        form = SignupForm(request.POST)

        if form.is_valid():
            usuario = form.save()

            PerfilUsuario.objects.create(usuario=usuario)
            team = Team.objects.create(name='El nombre del Team', creado_por=usuario)
            team.miembros.add(usuario)
            team.save()

            messages.success(request, 'Usuario creado exitosamente.')
            # Redirigir a la vista de inicio de sesión usando reverse
            return redirect(reverse('perfil_usuario:inicio_sesion'))
        
    else:
        form = SignupForm()

    return render(request, 'perfil_usuario/registro.html', {'form': form})

def dashboard(request):
    # Lógica de la vista del dashboard
    return render(request, 'perfil_usuario/dashboard.html')


@login_required
def micuenta(request):
    team = Team.objects.filter(creado_por=request.user).first()
    return render(request, 'perfil_usuario/micuenta.html', {'team': team})


def inicio_sesion(request):
    if request.method == 'POST':
        form = AuthenticationForm(request, request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            return redirect('index')  # Redirigir a la página principal
    else:
        form = AuthenticationForm(request)

    return render(request, 'perfil_usuario/inicio_sesion.html', {'form': form})







