from django.contrib import admin

from .models import PerfilUsuario

admin.site.register(PerfilUsuario)