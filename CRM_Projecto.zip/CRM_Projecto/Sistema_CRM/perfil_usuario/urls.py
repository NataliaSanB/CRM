from django.urls import path
from . import views

app_name = 'perfil_usuario'

urlpatterns = [
    path('registro/', views.registro, name='registro'),
    path('micuenta/', views.micuenta, name='micuenta'), 
    path('inicio_sesion/', views.inicio_sesion, name='inicio_sesion'),
    
]

